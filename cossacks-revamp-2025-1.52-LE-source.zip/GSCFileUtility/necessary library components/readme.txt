These components you need to install and register in case you run gsc utility and get the error that these components are not installed.
To install, unrar and extract the required file. Drop them in your windows/system32 folder.
Then fire up run/execute/cmd depending whether you are on xp or Vista/Win7
Type the line: regsvr32 comctl32.ocx
Notice the space between the regsvr32 and the component name you are installing. Hit enter, it should give you the message that the component has been succesfully registered.

Note: if you have problems then you are probably on Vista or Windows7.It is essential that you go to the windows arch and type cmd , when it appears in the list, then right click and run as admin. Proceed as explained above.

Credits: cossacksworld.ucoz.co.uk