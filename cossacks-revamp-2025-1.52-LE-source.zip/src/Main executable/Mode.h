#define COPYSCR
//#define ScreenSizeX 1024
//#define ScreenSizeY 768
#define clrRed 0xCD
#define clrGreen 0x9B
#define clrBlue 0xCE
#define clrYello 0xFB
#define clrBlack 0
#define clrWhite 0xFF
