void LoadSounds(char* fn);
void PlayEffect(int n,int pan,int vol);
void AddSingleEffect(int x,int y,int id);
void AddEffect(int x,int y,int id);

void AddWorkEffect(int x,int y,int id);
void AddOrderEffect(int x,int y,int id);
void AddWarEffect(int x,int y,int id);
extern word NSounds;