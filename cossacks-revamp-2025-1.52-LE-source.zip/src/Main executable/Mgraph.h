void OutErr(LPCSTR s);
void LoadFon();
void ShowFon();
void LoadTiles();
void LoadMap(LPCSTR s);
void ShowMap();
void HandleMouse(int x,int y);
