void Hline(int x,int y,int xend,byte c);
void Vline(int x,int y,int yend,byte c);
void Xbar(int x,int y,int lx,int ly,byte c);
void DrawLine(int x,int y,int x1,int y1,byte c);